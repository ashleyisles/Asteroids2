//
//  InputHandler.hpp
//  GameEngine
//
//  Created by David Lively on 2/22/16.
//  Copyright © 2016 David Lively. All rights reserved.
//

#ifndef INPUTHANDLER_H
#define INPUTHANDLER_H

#include "GameObject.h"

class InputHandler : public GameObject
{
public:
private:

};


#endif /* InputHandler_hpp */
